import React, { useContext } from "react";
import { Context } from "../context/Blogcontext";
import {View,Text,StyleSheet, Button, TouchableOpacity} from "react-native"
import { FlatList } from "react-native-gesture-handler";
import { Feather } from '@expo/vector-icons';

export default function IndexScreen({navigation})
{
    const {state,addBlogPost,deleteBlogPost}= useContext(Context);

    
    
    return(
        <View>
            
            <FlatList
            data={state}
            renderItem={({item})=>
            {
                return(
                    <TouchableOpacity  onPress={()=>navigation.navigate("Show",{id:item.id})}>
                        <View style={style.row}>
                            
                                <Text style={style.title}>{item.title}</Text>
                                <Feather name="trash" onPress={()=>deleteBlogPost(item.id)}  style={style.icon}/>
                        
                        </View>
                    </TouchableOpacity>
                )
            }}
            keyExtractor={x=>x.title}
            />
        </View>
    )
}

    IndexScreen.navigationOptions = ({ navigation }) => {
        return {
            headerRight: () => (
                <TouchableOpacity onPress={() => navigation.navigate("Create")}>
                    <Feather name="plus" size={30} style={{ marginRight: 15 }} />
                </TouchableOpacity>
            ),
        };
    
    ;
};


const style = StyleSheet.create(
    {
        row:
        {
            flexDirection:"row",
            justifyContent:"space-between",
            paddingVertical:20,
            borderWidth:1,
            borderBottomWidth:1,
            borderColor:"gray"
        },
        title:{
            fontSize:18
        },
        icon:
        {
            fontSize:24
        }
    }
)