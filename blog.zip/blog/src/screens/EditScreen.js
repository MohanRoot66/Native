import React, { useContext } from 'react';
import { Context } from '../context/Blogcontext';
import BlogPostForm from '../component/BlogPostForm';

export default function EditScreen({ navigation }) {
  // Extracting the 'id' parameter from the route
  const fetched_id = navigation.getParam("id")
  // Using the 'useContext' hook to access the state from the 'Blogcontext'
 
  const {state} = useContext(Context);

  const blogpost = state.find(x=>x.id===fetched_id)
  
  // Rendering the title and content of the blog post
  return (
    <BlogPostForm intialValues={{title:blogpost.title,content:blogpost.content}} onSubmit={(title,content)=>console.log(title,content)}/>
  );
}
