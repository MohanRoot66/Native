import React, { useContext } from "react";
import { Context } from "../context/Blogcontext";
import { EvilIcons } from "@expo/vector-icons";
import { View, Text, StyleSheet } from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";

export default function ShowScreen({ route, navigation }) {
  const id = navigation.getParam("id");
  const { state } = useContext(Context);
  const blog = state.find((x) => x.id === id);

  return (
    <View>
      <Text>{blog.title}</Text>
      <Text>{blog.content}</Text>
    </View>
  );
}

const style = StyleSheet.create({});

ShowScreen.navigationOptions = ({ navigation, route }) => {
  return {
    headerRight: () => (
      <TouchableOpacity
        onPress={() => {
          const fetched_id = navigation.getParam("id")
          navigation.navigate("Edit", { id:fetched_id });
        }}
      >
        <EvilIcons name="pencil" size={34} />
      </TouchableOpacity>
    ),
  };
};
