import { View, Text,StyleSheet,TextInput,Button} from 'react-native'
import React,{useState,useContext} from 'react';
import { Context } from '../context/Blogcontext';
export default function BlogPostForm({intialValues={title:"",content:""},id,onSubmit}) {


    
  const [title,setTitle] = useState(intialValues.title);
  const [content,setContent] = useState(intialValues.content)

    return ( 
         <View>
          <Text style={style.label}>Create :</Text>
          <TextInput 
          style={style.input}
          value={title}  
          onChangeText={(text)=>setTitle(text)}
          />
          <Text style={style.label}>Enter Content : </Text>
          <TextInput 
          style={style.input}
          value={content} onChangeText={(text)=>setContent(text)}/>
          <Button title="Save Blog Post" onPress={()=>{onSubmit(title,content)}}   />
        </View>
      )
}

const style = StyleSheet.create(
    {
        input:
        {
          fontSize:18,
          borderWidth:1,
          borderColor:"black",
          marginBottom:15,
          padding:5,
          margin:5
        },
        label:
        {
          marginBottom:5,
          fontSize:20,
          marginLeft:5
        }
    }
)